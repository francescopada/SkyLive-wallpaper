# Sky Live – live wallpaper Android procedurale

Cielo visto dal basso, tutto in shader OpenGL ES 3.0 (nessuna immagine/video).

## Build
1. Apri la cartella in Android Studio (Koala o più recente) → Sync → Run su un dispositivo reale.
2. Apri l'app "Sky Live" → "Imposta come sfondo".

## Cosa c'è
- Atmosfera Rayleigh/Mie analitica: alba, tramonto, ora blu, notte
- Sole, luna con fasi reali, stelle e Via Lattea (ruotano con l'ora siderale, latitudine/longitudine configurabili)
- Nuvole volumetriche (raymarching, rumore 3D, forward scattering / silver lining)
- Meteo automatico: sereno → nuvoloso → pioggia → temporale (fulmini, pioggia a strisce)
- Uccelli: formazioni a V, stormi sparsi, singoli, con battito d'ali
- Giroscopio, qualità adattiva, risoluzione ridotta, pausa quando non visibile

## Ritocchi rapidi (Shaders.kt)
SUN_E / SKY_GAIN = luminosità cielo · `expo` in main() = esposizione · `sig` in clouds() = densità nuvole
· `th` in cloudDensity() = copertura · BirdSystem.baseSize = dimensione uccelli
