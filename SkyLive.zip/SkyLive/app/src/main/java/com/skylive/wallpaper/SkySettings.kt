package com.skylive.wallpaper

import android.content.SharedPreferences

/** Impostazioni condivise fra servizio e thread di rendering. */
class SkySettings {
    @Volatile var timeScale = 1f
    @Volatile var weather = "auto"
    @Volatile var quality = "auto"
    @Volatile var camera = "follow"
    @Volatile var gyro = true
    @Volatile var birds = true
    @Volatile var lat = 41.9
    @Volatile var lon = 12.5
    @Volatile var tiltRoll = 0f
    @Volatile var tiltPitch = 0f

    val resScale: Float
        get() = when (quality) { "low" -> 0.5f; "high" -> 0.85f; "mid" -> 0.65f; else -> 0.6f }
    val fps: Int
        get() = when (quality) { "low" -> 24; "high" -> 40; else -> 30 }

    fun load(p: SharedPreferences) {
        timeScale = p.getString("time_scale", "1")?.toFloatOrNull() ?: 1f
        weather = p.getString("weather", "auto") ?: "auto"
        quality = p.getString("quality", "auto") ?: "auto"
        camera = p.getString("camera", "follow") ?: "follow"
        gyro = p.getBoolean("gyro", true)
        birds = p.getBoolean("birds", true)
        lat = (p.getString("lat", "41.9")?.toDoubleOrNull() ?: 41.9).coerceIn(-89.0, 89.0)
        lon = (p.getString("lon", "12.5")?.toDoubleOrNull() ?: 12.5).coerceIn(-180.0, 180.0)
    }
}
