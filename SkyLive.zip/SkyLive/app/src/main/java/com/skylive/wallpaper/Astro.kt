package com.skylive.wallpaper

import kotlin.math.*

/** Direzioni (est, su, nord) di sole e luna + matrice che porta le direzioni locali in coordinate equatoriali. */
class SkyState {
    val sun = FloatArray(3)
    val moon = FloatArray(3)
    val s0 = FloatArray(3)
    val s1 = FloatArray(3)
    val s2 = FloatArray(3)
}

object Astro {
    private const val RAD = Math.PI / 180.0

    fun compute(ms: Double, latDeg: Double, lonDeg: Double, o: SkyState) {
        val d = ms / 86400000.0 - 10957.5 // giorni da J2000
        val eps = (23.439 - 4.0e-7 * d) * RAD

        // Sole
        val l0 = 280.460 + 0.9856474 * d
        val g = (357.528 + 0.9856003 * d) * RAD
        val lam = (l0 + 1.915 * sin(g) + 0.020 * sin(2 * g)) * RAD
        val raS = atan2(cos(eps) * sin(lam), cos(lam))
        val decS = asin(sin(eps) * sin(lam))

        // Luna (bassa precisione, sufficiente per fase e posizione)
        val lm = (218.316 + 13.176396 * d) * RAD
        val mm = (134.963 + 13.064993 * d) * RAD
        val f = (93.272 + 13.229350 * d) * RAD
        val lonM = lm + 6.289 * RAD * sin(mm)
        val latM = 5.128 * RAD * sin(f)
        val decM = asin(sin(latM) * cos(eps) + cos(latM) * sin(eps) * sin(lonM))
        val raM = atan2(sin(lonM) * cos(eps) - tan(latM) * sin(eps), cos(lonM))

        val lst = (280.46061837 + 360.98564736629 * d + lonDeg) * RAD
        val phi = latDeg * RAD
        val sp = sin(phi)
        val cp = cos(phi)

        fun dir(ra: Double, dec: Double, out: FloatArray) {
            val h = lst - ra
            val cd = cos(dec)
            out[0] = (-cd * sin(h)).toFloat()
            out[1] = (cd * cos(h) * cp + sin(dec) * sp).toFloat()
            out[2] = (-cd * cos(h) * sp + sin(dec) * cp).toFloat()
        }
        dir(raS, decS, o.sun)
        dir(raM, decM, o.moon)

        val ct = cos(lst)
        val st = sin(lst)
        o.s0[0] = (-st).toFloat(); o.s0[1] = (ct * cp).toFloat(); o.s0[2] = (-ct * sp).toFloat()
        o.s1[0] = ct.toFloat();    o.s1[1] = (st * cp).toFloat(); o.s1[2] = (-st * sp).toFloat()
        o.s2[0] = 0f;              o.s2[1] = sp.toFloat();        o.s2[2] = cp.toFloat()
    }
}
