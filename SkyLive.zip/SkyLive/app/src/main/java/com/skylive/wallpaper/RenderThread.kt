package com.skylive.wallpaper

import android.opengl.*
import android.util.Log
import android.view.Surface
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/** Thread EGL/OpenGL ES 3.0 con limite di fps, pausa e qualità adattiva. */
class RenderThread(private val surface: Surface, private val cfg: SkySettings) : Thread("SkyRender") {
    private val lock = ReentrantLock()
    private val cond = lock.newCondition()
    @Volatile private var running = true
    @Volatile private var paused = true

    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var eglContext: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private val dims = IntArray(1)

    fun setPaused(p: Boolean) = lock.withLock { paused = p; cond.signalAll() }

    fun quit() {
        running = false
        lock.withLock { cond.signalAll() }
        try { join(2000) } catch (_: InterruptedException) {}
    }

    private fun initEgl() {
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2)
        EGL14.eglInitialize(display, v, 0, v, 1)
        val attrs = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, 0x40, // EGL_OPENGL_ES3_BIT_KHR
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<EGLConfig>(1)
        val num = IntArray(1)
        EGL14.eglChooseConfig(display, attrs, 0, configs, 0, 1, num, 0)
        val cfgEgl = configs[0] ?: throw RuntimeException("Nessuna config EGL ES3")
        eglContext = EGL14.eglCreateContext(display, cfgEgl, EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
        eglSurface = EGL14.eglCreateWindowSurface(display, cfgEgl, surface, intArrayOf(EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(display, eglSurface, eglSurface, eglContext)
        EGL14.eglSwapInterval(display, 1)
    }

    private fun surfaceSize(): Pair<Int, Int> {
        EGL14.eglQuerySurface(display, eglSurface, EGL14.EGL_WIDTH, dims, 0)
        val w = dims[0]
        EGL14.eglQuerySurface(display, eglSurface, EGL14.EGL_HEIGHT, dims, 0)
        return Pair(w, dims[0])
    }

    private fun release() {
        if (display != EGL14.EGL_NO_DISPLAY) {
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display, eglSurface)
            if (eglContext != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display, eglContext)
            EGL14.eglTerminate(display)
        }
        display = EGL14.EGL_NO_DISPLAY
    }

    override fun run() {
        try {
            initEgl()
            val renderer = SkyRenderer(cfg)
            renderer.init()
            var last = System.nanoTime()
            var slow = 0
            var fast = 0
            while (running) {
                var wasPaused = false
                lock.withLock { while (running && paused) { wasPaused = true; cond.await() } }
                if (!running) break
                if (wasPaused) last = System.nanoTime()

                val start = System.nanoTime()
                val dt = (start - last) / 1e9f
                last = start

                val (w, h) = surfaceSize()
                if (w > 0 && h > 0) {
                    when (cfg.quality) {
                        "low" -> renderer.quality = 0
                        "mid" -> renderer.quality = 1
                        "high" -> renderer.quality = 2
                    }
                    renderer.draw(w, h, dt)
                    GLES30.glFinish()
                    val gpu = (System.nanoTime() - start) / 1e9f
                    EGL14.eglSwapBuffers(display, eglSurface)

                    // qualità adattiva (solo in modalità automatica)
                    val budget = 1f / cfg.fps
                    if (cfg.quality == "auto") {
                        if (gpu > budget * 0.95f) { slow++; fast = 0 }
                        else if (gpu < budget * 0.45f) { fast++; slow = 0 }
                        else { slow = 0; fast = 0 }
                        if (slow > 45 && renderer.quality > 0) { renderer.quality--; slow = 0 }
                        if (fast > 240 && renderer.quality < 2) { renderer.quality++; fast = 0 }
                    }
                    val sleepMs = ((budget - (System.nanoTime() - start) / 1e9f) * 1000f).toLong()
                    if (sleepMs > 1) sleep(sleepMs)
                } else sleep(50)
            }
        } catch (t: Throwable) {
            Log.e("SkyLive", "Errore di rendering", t)
        } finally {
            release()
        }
    }
}
