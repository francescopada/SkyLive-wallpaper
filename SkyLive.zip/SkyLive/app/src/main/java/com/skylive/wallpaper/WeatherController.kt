package com.skylive.wallpaper

import kotlin.math.*

/** Macchina a stati meteo con transizioni dolci + fulmini. */
class WeatherController {
    enum class Kind(
        val cover: Float, val dens: Float, val dark: Float, val rain: Float,
        val wind: Float, val haze: Float, val elec: Float
    ) {
        CLEAR(0.04f, 0.8f, 0.00f, 0.00f, 5f, 0.00f, 0f),
        FAIR(0.36f, 1.0f, 0.00f, 0.00f, 8f, 0.05f, 0f),
        CLOUDY(0.62f, 1.2f, 0.30f, 0.00f, 11f, 0.12f, 0f),
        OVERCAST(0.92f, 1.5f, 0.60f, 0.00f, 9f, 0.22f, 0f),
        RAIN(0.95f, 1.7f, 0.72f, 0.75f, 14f, 0.35f, 0f),
        STORM(1.00f, 2.0f, 0.92f, 1.00f, 22f, 0.40f, 1f)
    }

    // Valori correnti (già interpolati)
    var cover = 0.35f; var dens = 1f; var dark = 0f; var rain = 0f
    var wind = 8f; var haze = 0.05f; var elec = 0f
    var flash = 0f; var boltX = 0f; var boltY = 0.3f; var boltSeed = 1f; var boltI = 0f
    var ofsX = 0.0; var ofsY = 0.0; var ofsZ = 0.0

    private val rnd = java.util.Random()
    private var kind = Kind.FAIR
    private var timer = 300f
    private var windDir = 0.7f
    private var strikeT = 99f
    private var nextStrike = 6f
    private var t = 0f

    // ordine: CLEAR, FAIR, CLOUDY, OVERCAST, RAIN, STORM
    private val trans = arrayOf(
        floatArrayOf(0f, .70f, .25f, .05f, 0f, 0f),
        floatArrayOf(.30f, 0f, .40f, .15f, .10f, .05f),
        floatArrayOf(.10f, .25f, 0f, .30f, .25f, .10f),
        floatArrayOf(0f, .15f, .30f, 0f, .40f, .15f),
        floatArrayOf(0f, .10f, .30f, .30f, 0f, .30f),
        floatArrayOf(0f, .05f, .25f, .20f, .50f, 0f)
    )

    init {
        kind = Kind.values()[rnd.nextInt(3)]
        cover = kind.cover; dens = kind.dens; dark = kind.dark; rain = kind.rain
        wind = kind.wind; haze = kind.haze; elec = kind.elec
        windDir = rnd.nextFloat() * 6.28f
    }

    private fun pickNext(): Kind {
        val w = trans[kind.ordinal]
        var r = rnd.nextFloat() * w.sum()
        for (i in w.indices) { r -= w[i]; if (r <= 0f && w[i] > 0f) return Kind.values()[i] }
        return Kind.FAIR
    }

    fun update(dt: Float, mode: String, speed: Float) {
        t += dt
        val forced = when (mode) {
            "clear" -> Kind.CLEAR; "fair" -> Kind.FAIR; "cloudy" -> Kind.CLOUDY
            "rain" -> Kind.RAIN; "storm" -> Kind.STORM; else -> null
        }
        if (forced != null) kind = forced
        else {
            timer -= dt * speed
            if (timer <= 0f) { kind = pickNext(); timer = 240f + rnd.nextFloat() * 480f }
        }
        val k = 1f - exp(-dt * speed / 20f)
        cover += (kind.cover + 0.04f * sin(t * 0.02f) - cover) * k
        cover = cover.coerceIn(0f, 1f)
        dens += (kind.dens - dens) * k
        dark += (kind.dark - dark) * k
        rain += (kind.rain - rain) * k
        wind += (kind.wind - wind) * k
        haze += (kind.haze - haze) * k
        elec += (kind.elec - elec) * k

        // Vento: scorrimento + evoluzione interna delle nuvole
        val m = wind * 0.0017 * speed
        windDir += (rnd.nextFloat() - 0.5f) * 0.002f * dt
        ofsX += cos(windDir) * m * dt
        ofsZ += sin(windDir) * m * dt
        ofsY += 0.0006 * speed * dt
        if (abs(ofsX) > 3000 || abs(ofsZ) > 3000 || ofsY > 3000) { ofsX = 0.0; ofsY = 0.0; ofsZ = 0.0 }

        // Fulmini
        strikeT += dt
        if (elec > 0.5f) {
            nextStrike -= dt
            if (nextStrike <= 0f) {
                strikeT = 0f
                boltSeed = rnd.nextFloat() * 100f
                boltX = (rnd.nextFloat() - 0.5f) * 0.7f
                boltY = 0.1f + rnd.nextFloat() * 0.6f
                nextStrike = 3f + rnd.nextFloat() * 14f
            }
        }
        var f = 0f
        val pulses = floatArrayOf(0f, 1.0f, 0.09f, 0.7f, 0.22f, 0.9f)
        for (i in 0 until 3) {
            val x = strikeT - pulses[i * 2]
            if (x >= 0f) f = max(f, pulses[i * 2 + 1] * exp(-x * 9f))
        }
        flash = f * elec
        boltI = if (strikeT < 0.3f) f * elec else 0f
    }
}
