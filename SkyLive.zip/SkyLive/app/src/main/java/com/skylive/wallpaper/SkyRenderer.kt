package com.skylive.wallpaper

import android.opengl.GLES30
import java.nio.ByteBuffer
import kotlin.math.*

class SkyRenderer(private val cfg: SkySettings) {
    private val PI_F = Math.PI.toFloat()
    private var prog = 0
    private var birdProg = 0
    private var vao = 0
    private var noiseTex = 0
    private val locs = HashMap<String, Int>()
    private val birdLocs = HashMap<String, Int>()

    private val sky = SkyState()
    private val weather = WeatherController()
    private val birds = BirdSystem()

    /** 0..2: numero di passi del raymarching (6 / 9 / 13). */
    @Volatile var quality = 1
    private val stepsFor = intArrayOf(6, 9, 13)

    private var time = 0f
    private var simMs = System.currentTimeMillis().toDouble()
    private var camYaw = PI_F
    private var camPitch = 0.9f
    private var camInit = false
    private var refRoll = 0f
    private var refPitch = 0f
    private var gyroYaw = 0f
    private var gyroPitch = 0f
    private val fw = FloatArray(3)
    private val rt = FloatArray(3)
    private val up = FloatArray(3)
    private val birdA = FloatArray(BirdSystem.MAX * 4)
    private val birdB = FloatArray(BirdSystem.MAX * 4)
    private val FOV = 0.727f // tan(36°): semi-campo verticale

    fun init() {
        prog = link(compile(GLES30.GL_VERTEX_SHADER, Shaders.VERT), compile(GLES30.GL_FRAGMENT_SHADER, Shaders.FRAG))
        birdProg = link(compile(GLES30.GL_VERTEX_SHADER, Shaders.BIRD_VERT), compile(GLES30.GL_FRAGMENT_SHADER, Shaders.BIRD_FRAG))

        val v = IntArray(1)
        GLES30.glGenVertexArrays(1, v, 0); vao = v[0]

        // Texture di rumore 256x256 (R = valore, G = stesso valore traslato di (37,17) per il rumore 3D)
        val n = 256
        val base = ByteArray(n * n)
        java.util.Random(1234).nextBytes(base)
        val data = ByteArray(n * n * 2)
        for (y in 0 until n) for (x in 0 until n) {
            data[(y * n + x) * 2] = base[y * n + x]
            data[(y * n + x) * 2 + 1] = base[((y + 17) and 255) * n + ((x + 37) and 255)]
        }
        val buf = ByteBuffer.allocateDirect(data.size)
        buf.put(data).position(0)
        GLES30.glGenTextures(1, v, 0); noiseTex = v[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, noiseTex)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RG8, n, n, 0, GLES30.GL_RG, GLES30.GL_UNSIGNED_BYTE, buf)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
    }

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val st = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, st, 0)
        if (st[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(s)
            GLES30.glDeleteShader(s)
            throw RuntimeException("Errore shader: $log")
        }
        return s
    }

    private fun link(vs: Int, fs: Int): Int {
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, vs); GLES30.glAttachShader(p, fs)
        GLES30.glLinkProgram(p)
        val st = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, st, 0)
        if (st[0] == 0) throw RuntimeException("Errore link: " + GLES30.glGetProgramInfoLog(p))
        return p
    }

    private fun u(name: String) = locs.getOrPut(name) { GLES30.glGetUniformLocation(prog, name) }
    private fun bu(name: String) = birdLocs.getOrPut(name) { GLES30.glGetUniformLocation(birdProg, name) }

    private fun smooth(a: Float, b: Float, x: Float): Float {
        val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun approach(cur: Float, target: Float, maxStep: Float): Float {
        val d = target - cur
        return if (abs(d) <= maxStep) target else cur + sign(d) * maxStep
    }

    private fun updateCamera(dt: Float) {
        val tYaw: Float
        val tPitch: Float
        if (cfg.camera == "follow") {
            val useSun = sky.sun[1] > 0.06f || sky.moon[1] < 0.08f
            val b = if (useSun) sky.sun else sky.moon
            val el = asin(b[1].coerceIn(-1f, 1f))
            tYaw = atan2(b[0], b[2]) + 0.22f
            tPitch = (el * 0.8f + 0.30f).coerceIn(0.55f, 1.10f)
        } else {
            tYaw = PI_F; tPitch = 0.9f
        }
        if (!camInit) { camYaw = tYaw; camPitch = tPitch; camInit = true }
        else {
            var d = tYaw - camYaw
            while (d > PI_F) d -= 2f * PI_F
            while (d < -PI_F) d += 2f * PI_F
            val rate = min(cfg.timeScale.coerceAtLeast(1f) * 0.006f, 0.5f) * dt
            camYaw = camYaw + d.coerceIn(-rate, rate)
            camPitch = approach(camPitch, tPitch, rate * 0.7f)
        }

        // Giroscopio: filtro passa-alto, la vista torna al centro in pochi secondi
        val k = 1f - exp(-dt / 4f)
        refRoll += (cfg.tiltRoll - refRoll) * k
        refPitch += (cfg.tiltPitch - refPitch) * k
        var ty = 0f
        var tp = 0f
        if (cfg.gyro) {
            ty = (-(cfg.tiltRoll - refRoll)).coerceIn(-0.35f, 0.35f)
            tp = (cfg.tiltPitch - refPitch).coerceIn(-0.35f, 0.35f)
        }
        val ks = 1f - exp(-dt * 6f)
        gyroYaw += (ty - gyroYaw) * ks
        gyroPitch += (tp - gyroPitch) * ks

        val yaw = camYaw + gyroYaw
        val p = (camPitch + gyroPitch).coerceIn(0.2f, 1.45f)
        val cp = cos(p)
        fw[0] = sin(yaw) * cp; fw[1] = sin(p); fw[2] = cos(yaw) * cp
        // right = cross((0,1,0), fwd), up = ortogonalizzato
        var rx = fw[2]; var rz = -fw[0]
        val rl = sqrt(rx * rx + rz * rz).coerceAtLeast(1e-5f)
        rx /= rl; rz /= rl
        rt[0] = rx; rt[1] = 0f; rt[2] = rz
        var ux = -fw[0] * fw[1]; var uy = 1f - fw[1] * fw[1]; var uz = -fw[2] * fw[1]
        val ul = sqrt(ux * ux + uy * uy + uz * uz).coerceAtLeast(1e-5f)
        ux /= ul; uy /= ul; uz /= ul
        up[0] = ux; up[1] = uy; up[2] = uz
    }

    fun draw(w: Int, h: Int, dtIn: Float) {
        val dt = dtIn.coerceIn(0.001f, 0.1f)
        time += dt

        if (cfg.timeScale <= 1.01f) simMs = System.currentTimeMillis().toDouble()
        else simMs += dt * 1000.0 * cfg.timeScale
        Astro.compute(simMs, cfg.lat, cfg.lon, sky)

        val speed = sqrt(cfg.timeScale.coerceAtLeast(1f)).coerceAtMost(8f)
        weather.update(dt, cfg.weather, speed)
        updateCamera(dt)

        val aspect = w.toFloat() / h.toFloat()
        val lf = smooth(-0.22f, 0.4f, sky.sun[1]).pow(1.6f)
        birds.update(dt, camYaw, camPitch, cfg.birds && weather.rain < 0.3f && lf > 0.08f)

        GLES30.glViewport(0, 0, w, h)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glUseProgram(prog)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, noiseTex)
        GLES30.glUniform1i(u("uNoise"), 0)
        GLES30.glUniform2f(u("uRes"), w.toFloat(), h.toFloat())
        GLES30.glUniform1f(u("uTime"), time % 3600f)
        GLES30.glUniform3f(u("uFwd"), fw[0], fw[1], fw[2])
        GLES30.glUniform3f(u("uRight"), rt[0], rt[1], rt[2])
        GLES30.glUniform3f(u("uUp"), up[0], up[1], up[2])
        GLES30.glUniform1f(u("uFov"), FOV)
        GLES30.glUniform3f(u("uSunDir"), sky.sun[0], sky.sun[1], sky.sun[2])
        GLES30.glUniform3f(u("uMoonDir"), sky.moon[0], sky.moon[1], sky.moon[2])
        GLES30.glUniform3f(u("uStar0"), sky.s0[0], sky.s0[1], sky.s0[2])
        GLES30.glUniform3f(u("uStar1"), sky.s1[0], sky.s1[1], sky.s1[2])
        GLES30.glUniform3f(u("uStar2"), sky.s2[0], sky.s2[1], sky.s2[2])
        GLES30.glUniform1f(u("uCover"), weather.cover)
        GLES30.glUniform1f(u("uDens"), weather.dens)
        GLES30.glUniform1f(u("uDark"), weather.dark)
        GLES30.glUniform1f(u("uRain"), weather.rain)
        GLES30.glUniform1f(u("uHaze"), weather.haze)
        GLES30.glUniform1f(u("uFlash"), weather.flash)
        GLES30.glUniform3f(u("uCloudOfs"), weather.ofsX.toFloat(), weather.ofsY.toFloat(), weather.ofsZ.toFloat())
        GLES30.glUniform4f(u("uBolt"), weather.boltX * aspect, weather.boltY, weather.boltSeed, weather.boltI)
        GLES30.glUniform1i(u("uSteps"), stepsFor[quality.coerceIn(0, 2)])
        GLES30.glBindVertexArray(vao)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)

        // Uccelli
        if (cfg.birds && lf > 0.05f) {
            val alpha = (lf * 3f).coerceIn(0f, 1f) * (1f - 0.6f * weather.dark)
            val n = birds.fill(birdA, birdB, fw, rt, up, FOV, aspect, alpha)
            if (n > 0) {
                GLES30.glEnable(GLES30.GL_BLEND)
                GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
                GLES30.glUseProgram(birdProg)
                GLES30.glUniform1f(bu("uAspect"), aspect)
                val c = 0.02f + 0.05f * lf
                GLES30.glUniform3f(bu("uColor"), c, c, c * 1.15f)
                GLES30.glUniform4fv(bu("uA"), n, birdA, 0)
                GLES30.glUniform4fv(bu("uB"), n, birdB, 0)
                GLES30.glDrawArraysInstanced(GLES30.GL_TRIANGLES, 0, 9, n)
                GLES30.glDisable(GLES30.GL_BLEND)
            }
        }
    }
}
