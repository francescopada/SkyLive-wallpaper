package com.skylive.wallpaper

import kotlin.math.*

/** Stormi di uccelli (formazione a V, stormi sparsi, singoli) che volano nello spazio angolare del cielo. */
class BirdSystem {
    companion object { const val MAX = 36 }

    private class Bird(val sf: Float, val sl: Float, val size: Float, val rate: Float, val gp: Float) {
        var x = 0f; var y = 0f; var phase = gp * 6.28f
    }
    private class Flock(var x: Float, var y: Float, var vx: Float, var vy: Float) {
        val birds = ArrayList<Bird>()
    }

    private val flocks = ArrayList<Flock>()
    private val rnd = java.util.Random()
    private var timer = 4f
    private var t = 0f
    private val tmp = FloatArray(2)
    private val tmp2 = FloatArray(2)

    fun update(dt: Float, camYaw: Float, camPitch: Float, allowed: Boolean) {
        t += dt
        if (allowed) {
            timer -= dt
            if (timer <= 0f) { spawn(camYaw, camPitch); timer = 25f + rnd.nextFloat() * 70f }
        }
        val k = 1f - exp(-dt * 2.5f)
        val iter = flocks.iterator()
        while (iter.hasNext()) {
            val f = iter.next()
            f.x += f.vx * dt
            f.y += f.vy * dt
            f.vy += (rnd.nextFloat() - 0.5f) * 0.004f * dt
            f.vy = f.vy.coerceIn(-0.012f, 0.012f)
            val camX = camYaw * cos(f.y)
            if (abs(f.x - camX) > 1.2f) { iter.remove(); continue }
            val hd = atan2(f.vy, f.vx)
            val cx = cos(hd); val sx = sin(hd)
            for (b in f.birds) {
                val tx = f.x - cx * b.sf - sx * b.sl
                val ty = f.y - sx * b.sf + cx * b.sl
                b.x += (tx - b.x) * k + sin(t * 1.7f + b.gp * 9f) * 0.002f * dt
                b.y += (ty - b.y) * k + cos(t * 1.3f + b.gp * 7f) * 0.002f * dt
                b.phase += dt * b.rate
            }
        }
    }

    private fun spawn(camYaw: Float, camPitch: Float) {
        val total = flocks.sumOf { it.birds.size }
        val dir = if (rnd.nextBoolean()) 1f else -1f
        val y = (camPitch + (rnd.nextFloat() - 0.5f) * 0.8f).coerceIn(0.45f, 1.3f)
        val speed = 0.035f + rnd.nextFloat() * 0.05f
        val f = Flock((camYaw - dir * 0.8f) * cos(y), y, dir * speed, (rnd.nextFloat() - 0.5f) * 0.01f)
        val type = rnd.nextInt(10)
        val n = when {
            type < 4 -> 5 + rnd.nextInt(7)
            type < 8 -> 6 + rnd.nextInt(10)
            else -> 1 + rnd.nextInt(3)
        }
        if (total + n > MAX) return
        val baseSize = 0.0065f + rnd.nextFloat() * 0.005f
        val hd = atan2(f.vy, f.vx)
        val cx = cos(hd); val sx = sin(hd)
        for (i in 0 until n) {
            val sf: Float; val sl: Float
            when {
                type < 4 -> {
                    if (i == 0) { sf = 0f; sl = 0f }
                    else { val r = (i + 1) / 2; val s = if (i % 2 == 0) 1f else -1f; sf = r * 0.022f; sl = s * r * 0.017f }
                }
                type < 8 -> { sf = rnd.nextFloat() * 0.12f; sl = (rnd.nextFloat() - 0.5f) * 0.12f }
                else -> { sf = rnd.nextFloat() * 0.04f; sl = (rnd.nextFloat() - 0.5f) * 0.04f }
            }
            val b = Bird(sf, sl, baseSize * (0.85f + rnd.nextFloat() * 0.3f), 7f + rnd.nextFloat() * 4f, rnd.nextFloat())
            b.x = f.x - cx * sf - sx * sl
            b.y = f.y - sx * sf + cx * sl
            f.birds.add(b)
        }
        flocks.add(f)
    }

    private fun proj(x: Float, y: Float, fw: FloatArray, rt: FloatArray, up: FloatArray, fov: Float, out: FloatArray): Boolean {
        val az = x / max(cos(y), 0.25f)
        val dx = sin(az) * cos(y); val dy = sin(y); val dz = cos(az) * cos(y)
        val z = dx * fw[0] + dy * fw[1] + dz * fw[2]
        if (z < 0.05f) return false
        out[0] = (dx * rt[0] + dy * rt[1] + dz * rt[2]) / z / fov
        out[1] = (dx * up[0] + dy * up[1] + dz * up[2]) / z / fov
        return true
    }

    /** Riempie gli array per lo shader. Ritorna il numero di uccelli visibili. */
    fun fill(
        a: FloatArray, b: FloatArray, fw: FloatArray, rt: FloatArray, up: FloatArray,
        fov: Float, aspect: Float, alpha: Float
    ): Int {
        var n = 0
        for (f in flocks) {
            for (bd in f.birds) {
                if (n >= MAX) return n
                if (!proj(bd.x, bd.y, fw, rt, up, fov, tmp)) continue
                if (abs(tmp[0]) > aspect + 0.1f || abs(tmp[1]) > 1.1f) continue
                var heading = 0f
                if (proj(bd.x + f.vx * 0.25f, bd.y + f.vy * 0.25f, fw, rt, up, fov, tmp2))
                    heading = atan2(tmp2[1] - tmp[1], tmp2[0] - tmp[0])
                val g = 0.5f + 0.5f * sin(t * 0.35f + bd.gp * 6.28f)
                val amp = if (g > 0.3f) 1f else 0.12f
                a[n * 4] = tmp[0]; a[n * 4 + 1] = tmp[1]; a[n * 4 + 2] = bd.size; a[n * 4 + 3] = heading
                b[n * 4] = sin(bd.phase) * amp; b[n * 4 + 1] = alpha; b[n * 4 + 2] = 0f; b[n * 4 + 3] = 0f
                n++
            }
        }
        return n
    }
}
