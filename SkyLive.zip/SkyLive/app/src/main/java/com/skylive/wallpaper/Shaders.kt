package com.skylive.wallpaper

object Shaders {
    const val VERT = """#version 300 es
out vec2 vUv;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    vUv = p * 2.0 - 1.0;
    gl_Position = vec4(vUv, 0.0, 1.0);
}
"""

    const val BIRD_VERT = """#version 300 es
precision highp float;
uniform vec4 uA[36];
uniform vec4 uB[36];
uniform float uAspect;
out float vAlpha;
void main() {
    vec4 a = uA[gl_InstanceID];
    vec4 b = uB[gl_InstanceID];
    float s = b.x * 0.85;
    float span = cos(s);
    float sweep = sin(s) * 0.4;
    int id = gl_VertexID;
    int tri = id / 3;
    int k = id - tri * 3;
    vec2 v;
    if (tri == 0) {
        v = (k == 0) ? vec2(0.0, 0.18) : ((k == 1) ? vec2(span, -0.25 - sweep) : vec2(0.0, -0.38));
    } else if (tri == 1) {
        v = (k == 0) ? vec2(0.0, 0.18) : ((k == 1) ? vec2(-span, -0.25 - sweep) : vec2(0.0, -0.38));
    } else {
        v = (k == 0) ? vec2(-0.1, -0.3) : ((k == 1) ? vec2(0.1, -0.3) : vec2(0.0, 0.5));
    }
    vec2 dir = vec2(cos(a.w), sin(a.w));
    vec2 lat = vec2(-dir.y, dir.x);
    vec2 p = a.xy + a.z * (v.x * lat + v.y * dir);
    gl_Position = vec4(p.x / uAspect, p.y, 0.0, 1.0);
    vAlpha = b.y;
}
"""

    const val BIRD_FRAG = """#version 300 es
precision mediump float;
in float vAlpha;
uniform vec3 uColor;
out vec4 fragColor;
void main() {
    fragColor = vec4(uColor, vAlpha);
}
"""

    const val FRAG = """#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;

in vec2 vUv;
out vec4 fragColor;

uniform vec2 uRes;
uniform float uTime;
uniform vec3 uFwd;
uniform vec3 uRight;
uniform vec3 uUp;
uniform float uFov;
uniform vec3 uSunDir;
uniform vec3 uMoonDir;
uniform vec3 uStar0;
uniform vec3 uStar1;
uniform vec3 uStar2;
uniform float uCover;
uniform float uDens;
uniform float uDark;
uniform float uRain;
uniform float uHaze;
uniform float uFlash;
uniform vec3 uCloudOfs;
uniform vec4 uBolt;
uniform int uSteps;
uniform sampler2D uNoise;

const float PI = 3.14159265;
const float SUN_E = 65.0;
const float SKY_GAIN = 2.2;
const float MOON_E = 1.4;
const float Y0 = 1700.0;
const float Y1 = 3700.0;
const vec3 TAU_R = vec3(0.040, 0.100, 0.240);
const float TAU_M = 0.025;

// ---------- hash / noise ----------
float hash11(float p) { p = fract(p * 0.1031); p *= p + 33.33; p *= p + p; return fract(p); }
float hash12(vec2 p) { vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
vec3 hash33(vec3 p3) {
    p3 = fract(p3 * vec3(0.1031, 0.1030, 0.0973));
    p3 += dot(p3, p3.yxz + 33.33);
    return fract((p3.xxy + p3.yxx) * p3.zyx);
}

float noise3(vec3 x) {
    vec3 p = floor(x);
    vec3 f = fract(x);
    f = f * f * (3.0 - 2.0 * f);
    vec2 uv = (p.xy + vec2(37.0, 17.0) * p.z) + f.xy;
    vec2 rg = textureLod(uNoise, (uv + 0.5) / 256.0, 0.0).rg;
    return mix(rg.x, rg.y, f.z);
}

float fbm(vec3 p, int oct) {
    float a = 0.5; float s = 0.0; float n = 0.0;
    for (int i = 0; i < 5; i++) {
        if (i >= oct) break;
        s += a * noise3(p); n += a;
        p = p * 2.03 + vec3(1.7, 9.2, 3.1);
        a *= 0.5;
    }
    return s / n;
}

float hg(float c, float g) {
    float g2 = g * g;
    return (1.0 - g2) / (4.0 * PI * pow(1.0 + g2 - 2.0 * g * c, 1.5));
}

// ---------- atmosfera ----------
float airmass(float c) { return 1.0 / (max(c, 0.0) + 0.0275); }
vec3 sunTransmit(float c) { return exp(-(TAU_R + TAU_M) * airmass(c)); }
float dayFactor(float sy) { float t = smoothstep(-0.22, 0.4, sy); return pow(t, 1.6); }

vec3 skyRadiance(vec3 rd, vec3 sd) {
    float ry = max(rd.y, 0.0);
    float am = airmass(ry);
    float cosS = max(sd.y + 0.25 * sqrt(ry), 0.0);
    vec3 Ts = sunTransmit(cosS);
    float tm = TAU_M * (1.0 + 6.0 * uHaze);
    vec3 tot = TAU_R + vec3(tm);
    vec3 fR = TAU_R / tot;
    vec3 fM = vec3(tm) / tot;
    float mu = dot(rd, sd);
    vec3 ph = fR * (0.0597 * (1.0 + mu * mu)) + fM * hg(mu, 0.76);
    vec3 sc = 1.0 - exp(-tot * am);
    return SUN_E * Ts * ph * sc * dayFactor(sd.y) * SKY_GAIN;
}

vec3 twilightGlow(vec3 rd, vec3 sd) {
    float w = exp(-abs(sd.y + 0.03) * 9.0) * smoothstep(-0.30, -0.10, sd.y);
    vec2 a = normalize(rd.xz + vec2(1e-4));
    vec2 b = normalize(sd.xz + vec2(1e-4));
    float az = 0.3 + 0.7 * pow(max(dot(a, b), 0.0), 2.0);
    float hgt = exp(-max(rd.y, 0.0) * 2.4);
    return vec3(1.0, 0.36, 0.20) * w * az * hgt * 2.2;
}

// ---------- stelle ----------
vec3 starsLayer(vec3 e, float N, float thr, float bright, float pixA) {
    float M = floor(PI * N);
    float phi = atan(e.y, e.x);
    if (phi < 0.0) phi += 2.0 * PI;
    vec2 g = vec2(phi / (2.0 * PI) * M, (e.z * 0.5 + 0.5) * N);
    vec2 ic = floor(g);
    vec3 acc = vec3(0.0);
    float rad = pixA * 1.1;
    for (int j = -1; j <= 1; j++) {
        for (int i = -1; i <= 1; i++) {
            vec2 c = ic + vec2(float(i), float(j));
            if (c.y < 0.0 || c.y >= N) continue;
            c.x = mod(c.x, M);
            vec3 h = hash33(vec3(c, N));
            if (h.x < thr) continue;
            vec2 sp = c + 0.15 + 0.7 * h.yz;
            float ph = sp.x / M * 2.0 * PI;
            float z = sp.y / N * 2.0 - 1.0;
            float r = sqrt(max(1.0 - z * z, 0.0));
            vec3 sdir = vec3(r * cos(ph), r * sin(ph), z);
            float d = length(e - sdir);
            float h2 = hash12(c + N * 13.7);
            float mag = 0.25 + 2.2 * pow(h2, 6.0);
            float tw = 1.0 + 0.3 * sin(uTime * (2.5 + 6.0 * fract(h2 * 7.3)) + h2 * 50.0);
            vec3 tint = mix(vec3(1.0, 0.75, 0.55), vec3(0.65, 0.78, 1.0), fract(h2 * 13.1));
            float core = 1.0 - smoothstep(0.0, rad, d);
            float halo = exp(-d / (rad * 3.0)) * 0.06 * step(1.2, mag);
            acc += tint * (core * mag * tw + halo * mag) * bright;
        }
    }
    return acc;
}

vec3 milkyWay(vec3 e) {
    const vec3 gp = vec3(-0.8677, -0.1981, 0.4560);
    const vec3 gc = vec3(-0.0560, -0.8734, -0.4841);
    float b = dot(e, gp);
    float band = exp(-b * b * 18.0);
    float core = pow(max(dot(e, gc), 0.0), 3.0);
    vec3 q = e * 6.0;
    float n = noise3(q) * 0.55 + noise3(q * 2.3) * 0.3 + noise3(q * 5.1) * 0.15;
    float dust = smoothstep(0.35, 0.8, noise3(q * 3.0 + 7.0));
    float v = band * (0.35 + 0.9 * core) * (0.35 + n) * (1.0 - 0.6 * dust * exp(-b * b * 40.0));
    return mix(vec3(0.50, 0.60, 1.0), vec3(1.0, 0.85, 0.6), core) * v * 0.12;
}

// ---------- luna ----------
vec4 moonDisc(vec3 rd, vec3 md, vec3 sd) {
    float mu = dot(rd, md);
    const float R = 0.045;
    float x = 1.0 - mu;
    float x0 = R * R * 0.5;
    if (x > x0 * 1.3) return vec4(0.0);
    vec3 w = -md;
    vec3 upv = abs(md.y) > 0.98 ? vec3(1.0, 0.0, 0.0) : vec3(0.0, 1.0, 0.0);
    vec3 t1 = normalize(cross(w, upv));
    vec3 t2 = cross(w, t1);
    vec3 o = rd - md * mu;
    vec2 xy = vec2(dot(o, t1), dot(o, t2)) / R;
    float r2 = dot(xy, xy);
    float edge = 1.0 - smoothstep(0.94, 1.0, r2);
    if (edge <= 0.0) return vec4(0.0);
    float z = sqrt(max(1.0 - r2, 0.0));
    vec3 n = xy.x * t1 + xy.y * t2 + z * w;
    float lit = smoothstep(-0.03, 0.12, dot(n, sd));
    vec3 sp = vec3(xy, z) * 2.0;
    float maria = smoothstep(0.42, 0.6, noise3(sp * 0.9 + vec3(3.1, 1.7, 5.2)) * 0.7 + noise3(sp * 2.1) * 0.3);
    float det = noise3(sp * 7.0) * 0.5 + noise3(sp * 15.0) * 0.5;
    float alb = (0.85 - 0.38 * maria + 0.12 * (det - 0.5)) * (0.65 + 0.35 * z);
    vec3 col = vec3(1.0, 0.97, 0.9) * alb * (lit * 8.0 + 0.12);
    return vec4(col, edge);
}

// ---------- nuvole ----------
float cloudDensity(vec3 p, int oct, bool erode) {
    if (p.y < Y0 || p.y > Y1) return 0.0;
    float h = clamp((p.y - Y0) / (Y1 - Y0), 0.0, 1.0);
    vec3 q = p * vec3(0.00042, 0.0007, 0.00042) + uCloudOfs;
    float n = fbm(q, oct);
    float prof = smoothstep(0.0, 0.14, h) * (1.0 - smoothstep(0.5, 1.0, h));
    float s = n * 0.9 + prof * 0.38;
    float th = mix(1.08, 0.60, uCover);
    float d = clamp((s - th) * 2.6, 0.0, 1.0);
    if (erode && d > 0.02) {
        float er = noise3(q * 6.1 + vec3(4.0, 1.0, 7.0));
        d = clamp(d - (1.0 - er) * 0.3 * (1.0 - 0.5 * d), 0.0, 1.0);
    }
    return d;
}

vec4 clouds(vec3 rd, vec3 L, vec3 lightCol, vec3 amb, float dither) {
    if (rd.y < 0.03 || uCover < 0.03) return vec4(0.0, 0.0, 0.0, 1.0);
    float t0 = Y0 / rd.y;
    float t1 = Y1 / rd.y;
    float dt = (t1 - t0) / float(uSteps);
    float t = t0 + dt * dither;
    float cosT = dot(rd, L);
    vec3 col = vec3(0.0);
    float T = 1.0;
    float sig = 0.0035 * uDens;
    for (int i = 0; i < 16; i++) {
        if (i >= uSteps || T < 0.03) break;
        vec3 p = rd * t;
        float d = cloudDensity(p, 4, true);
        if (d > 0.003) {
            float od = d * dt * sig;
            float ld = (cloudDensity(p + L * 300.0, 2, false) * 300.0 + cloudDensity(p + L * 800.0, 2, false) * 500.0) * sig;
            float h = clamp((p.y - Y0) / (Y1 - Y0), 0.0, 1.0);
            float scat = 0.0; float a = 1.0; float b = 1.0; float g = 1.0;
            for (int k = 0; k < 3; k++) {
                float ph = mix(hg(cosT, -0.15 * g), hg(cosT, 0.65 * g), 0.4);
                scat += a * exp(-ld * b) * ph;
                a *= 0.5; b *= 0.5; g *= 0.55;
            }
            vec3 S = lightCol * scat + amb * mix(0.4, 1.0, h);
            float stepT = exp(-od);
            col += T * (1.0 - stepT) * S;
            T *= stepT;
        }
        t += dt;
    }
    return vec4(col, T);
}

// ---------- fulmine ----------
float sdSeg(vec2 p, vec2 a, vec2 b) {
    vec2 pa = p - a; vec2 ba = b - a;
    float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
    return length(pa - ba * h);
}

float boltDist(vec2 p, vec2 a, float seed) {
    float d = 1e3;
    vec2 prev = a;
    float ang = (hash11(seed) - 0.5) * 0.8;
    for (int i = 0; i < 12; i++) {
        ang += (hash11(seed + float(i) * 7.31) - 0.5) * 1.3;
        ang = clamp(ang, -1.2, 1.2);
        vec2 nx = prev + vec2(sin(ang), -cos(ang)) * 0.09;
        d = min(d, sdSeg(p, prev, nx));
        prev = nx;
    }
    return d;
}

vec3 boltColor(vec2 uv) {
    if (uBolt.w <= 0.001) return vec3(0.0);
    float d = boltDist(uv, uBolt.xy, uBolt.z);
    float d2 = boltDist(uv, uBolt.xy + vec2(0.06, -0.2), uBolt.z + 11.0);
    float core = (1.0 - smoothstep(0.0, 0.008, d)) + 0.5 * (1.0 - smoothstep(0.0, 0.005, d2));
    float glow = 0.5 * exp(-d * 28.0) + 0.25 * exp(-d2 * 35.0);
    return vec3(0.75, 0.82, 1.0) * (core * 2.0 + glow) * uBolt.w * 30.0;
}

// ---------- pioggia (strisce che convergono verso lo zenit) ----------
float rainMask(vec3 rd) {
    vec2 p = rd.xz / max(rd.y, 0.12);
    float r = length(p);
    float a = atan(p.y, p.x) / 6.2831853 + 0.5;
    float rr = log(r + 0.15);
    float m = 0.0;
    for (int i = 0; i < 3; i++) {
        float fi = float(i);
        float n = 90.0 + fi * 50.0;
        float ga = a * n;
        float id = floor(ga);
        float f = fract(ga);
        float h = hash11(id * 1.37 + fi * 19.7);
        float line = 1.0 - smoothstep(0.0, 0.07, abs(f - 0.5));
        float s = fract(rr * 4.0 * (1.0 + h * 0.5) - uTime * (1.2 + fi * 0.4 + h) + h * 7.0);
        float shape = smoothstep(0.0, 0.03, s) * (1.0 - smoothstep(0.05, 0.22, s));
        float present = step(0.45, hash11(id + fi * 3.3));
        m += line * shape * present * (0.5 + 0.25 * fi);
    }
    return m * 0.5;
}

vec3 aces(vec3 x) {
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

void main() {
    vec2 uv = vUv;
    uv.x *= uRes.x / uRes.y;
    vec3 rd = normalize(uFwd + (uv.x * uRight + uv.y * uUp) * uFov);
    vec3 sd = normalize(uSunDir);
    vec3 md = normalize(uMoonDir);

    float lf = dayFactor(sd.y);
    float illum = 0.5 * (1.0 - dot(sd, md));
    float moonUp = smoothstep(-0.06, 0.2, md.y);
    float nightV = 1.0 - smoothstep(-0.30, -0.05, sd.y);
    float pixA = 2.0 * uFov / uRes.y;

    // cielo
    vec3 sky = skyRadiance(rd, sd) + twilightGlow(rd, sd);
    sky += vec3(0.006, 0.011, 0.026) * nightV;
    float mu = dot(rd, md);
    sky += vec3(0.30, 0.40, 0.80) * 0.035 * illum * moonUp * nightV * (0.55 + 0.45 * pow(max(mu, 0.0), 3.0));

    if (nightV > 0.001) {
        vec3 e = vec3(dot(uStar0, rd), dot(uStar1, rd), dot(uStar2, rd));
        vec3 st = starsLayer(e, 40.0, 0.80, 1.6, pixA) + starsLayer(e, 90.0, 0.82, 1.0, pixA) + starsLayer(e, 200.0, 0.85, 0.7, pixA);
        vec3 mw = milkyWay(e);
        float fade = nightV * (1.0 - 0.75 * illum * moonUp) * smoothstep(0.0, 0.12, rd.y);
        sky += (st + mw) * fade;
    }

    // sole
    float sunVis = smoothstep(-0.03, 0.02, sd.y);
    float xs = 1.0 - dot(rd, sd);
    vec3 sunC = SUN_E * sunTransmit(max(sd.y, 0.0));
    float disc = 1.0 - smoothstep(0.0007, 0.00095, xs);
    sky += sunC * (disc * 0.9 + exp(-xs * 60.0) * 0.12 + exp(-xs * 400.0) * 0.35) * sunVis;

    // luna
    vec4 mo = moonDisc(rd, md, sd);
    if (mo.a > 0.0) {
        sky = mix(sky, mo.rgb * mix(1.0, 0.25, lf), mo.a * smoothstep(-0.03, 0.03, md.y));
    }
    float xm = 1.0 - mu;
    sky += vec3(0.6, 0.7, 1.0) * (exp(-xm * 180.0) * 0.35 + exp(-xm * 25.0) * 0.06) * illum * moonUp * (1.0 - 0.8 * lf);

    // luce per le nuvole
    vec3 Ts = sunTransmit(max(sd.y + 0.03, 0.0));
    float sunFade = smoothstep(-0.14, 0.0, sd.y);
    vec3 sunLight = SUN_E * Ts * sunFade;
    vec3 moonLight = vec3(0.55, 0.68, 1.0) * MOON_E * illum * moonUp * (1.0 - sunFade);
    float ls = dot(sunLight, vec3(0.333));
    float lm = dot(moonLight, vec3(0.333));
    vec3 L = normalize(sd * ls + md * lm + vec3(0.0, 1e-4, 0.0));
    vec3 lightCol = (sunLight + moonLight) * (1.0 - 0.75 * uDark);
    vec3 amb = skyRadiance(vec3(0.0, 1.0, 0.0), sd) * 0.65 + twilightGlow(rd, sd) * 0.8 + vec3(0.010, 0.015, 0.032);
    float al = dot(amb, vec3(0.333));
    amb = mix(amb, vec3(al), 0.7 * uDark) * (1.0 - 0.45 * uDark);
    amb += vec3(0.55, 0.65, 1.0) * uFlash * 3.0;

    float dither = fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715))));
    vec4 cl = clouds(rd, L, lightCol, amb, dither);
    vec3 col = sky * cl.a + cl.rgb;

    col += vec3(0.5, 0.6, 1.0) * uFlash * 1.2;
    col += boltColor(uv);
    col = mix(col, col * 0.2, smoothstep(0.0, 0.10, -rd.y));

    float expo = mix(1.25, 0.36, lf);
    col *= expo;
    col = aces(col);
    col = pow(col, vec3(0.4545));
    float lum = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(vec3(lum), col, 1.12);

    if (uRain > 0.01) {
        float m = rainMask(rd);
        col += vec3(0.65, 0.72, 0.85) * (0.08 + 0.35 * lf) * uRain * m;
    }

    col *= 1.0 - 0.22 * dot(vUv, vUv) * 0.5;
    col += (hash12(gl_FragCoord.xy + fract(uTime) * 91.7) - 0.5) * 0.022;
    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
"""
}
