package com.skylive.wallpaper

import android.content.SharedPreferences
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.preference.PreferenceManager
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.asin
import kotlin.math.atan2

@Suppress("DEPRECATION")
class SkyWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = SkyEngine()

    inner class SkyEngine : Engine(), SensorEventListener, SharedPreferences.OnSharedPreferenceChangeListener {
        private val cfg = SkySettings()
        private val prefs: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(this@SkyWallpaperService)
        private var thread: RenderThread? = null
        private var sensorManager: SensorManager? = null
        private var visibleNow = false
        private var fixedW = 0
        private var fixedH = 0
        private val rot = FloatArray(9)

        override fun onCreate(holder: SurfaceHolder) {
            super.onCreate(holder)
            cfg.load(prefs)
            prefs.registerOnSharedPreferenceChangeListener(this)
            sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        }

        /** Rendering a risoluzione ridotta: il sistema scala l'immagine (grande risparmio di GPU). */
        private fun applyFixedSize() {
            val dm = resources.displayMetrics
            val s = cfg.resScale
            val fw = (dm.widthPixels * s).toInt().coerceAtLeast(64)
            val fh = (dm.heightPixels * s).toInt().coerceAtLeast(64)
            if (fw != fixedW || fh != fixedH) {
                fixedW = fw; fixedH = fh
                surfaceHolder.setFixedSize(fw, fh)
            }
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            applyFixedSize()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            applyFixedSize()
            if (thread == null) {
                thread = RenderThread(holder.surface, cfg).also {
                    it.start()
                    it.setPaused(!visibleNow)
                }
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            thread?.quit()
            thread = null
            super.onSurfaceDestroyed(holder)
        }

        override fun onVisibilityChanged(visible: Boolean) {
            visibleNow = visible
            thread?.setPaused(!visible)
            updateSensors()
        }

        override fun onDestroy() {
            prefs.unregisterOnSharedPreferenceChangeListener(this)
            sensorManager?.unregisterListener(this)
            super.onDestroy()
        }

        override fun onSharedPreferenceChanged(p: SharedPreferences, key: String?) {
            cfg.load(p)
            applyFixedSize()
            updateSensors()
        }

        private fun updateSensors() {
            val sm = sensorManager ?: return
            sm.unregisterListener(this)
            if (visibleNow && cfg.gyro) {
                val s = sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
                    ?: sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
                if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME)
            }
        }

        override fun onSensorChanged(e: SensorEvent) {
            SensorManager.getRotationMatrixFromVector(rot, e.values)
            cfg.tiltRoll = asin(rot[6].coerceIn(-1f, 1f))
            cfg.tiltPitch = atan2(rot[8], rot[7])
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
}
